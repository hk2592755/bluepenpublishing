
<section class="sec12 TestiSliderMain">
    <div class="container-fluid">
        <div class="row">
            <div class="col-md-4 whyChooseLeft">
                <div class="abtLeft">
                    <span class="smallTitleLine">Testimonials</span>
                    <h4>Discover Why Our Clients Trust Us.</h4>
                </div>
            </div>
        </div>
    </div>
    <div class="container-fluid">
        <div class="row">
            <div class="col-md-12 blogSlider">
                <div class="swiper mySwiperThree">
                    <div class="swiper-wrapper">
                        <div class="swiper-slide">
                            <div class="testiMainBox">
                                <div class="testinameImage">
                                    <span class="nameIco">DB</span>
                                    <div class="nameStars">
                                        <span class="clientNameTesti">Dove Barnham</span>
                                        <div class="ratingStar">
                                            <i class="fa-solid fa-star"></i>
                                            <i class="fa-solid fa-star"></i>
                                            <i class="fa-solid fa-star"></i>
                                            <i class="fa-solid fa-star"></i>
                                            <i class="fa-solid fa-star"></i>
                                        </div>
                                    </div>
                                </div>
                                <div class="blogContent">
                                    <p>Blue Pen Publishing wasn’t my first choice when it comes to ghostwriting, I had
                                        a
                                        very bad
                                        experience with my previous book writing agency, but things took a turn when I
                                        stumbled upon
                                        the website of Blue Pen Publishing; they helped me throughout my journey,
                                        their
                                        professionalism and their commitment towards my project really made this
                                        experience
                                        worthwhile.</p>
                                </div>
                            </div>
                        </div>
                        <div class="swiper-slide">
                            <div class="testiMainBox">
                                <div class="testinameImage">
                                    <span class="nameIco">CA</span>
                                    <div class="nameStars">
                                        <span class="clientNameTesti">Constantine Aubergine</span>
                                        <div class="ratingStar">
                                            <i class="fa-solid fa-star"></i>
                                            <i class="fa-solid fa-star"></i>
                                            <i class="fa-solid fa-star"></i>
                                            <i class="fa-solid fa-star"></i>
                                            <i class="fa-solid fa-star"></i>
                                        </div>
                                    </div>
                                </div>
                                <div class="blogContent">
                                    <p>I used to write short suspense thrillers, but I realized writing horror
                                        stories is a
                                        different ball
                                        game altogether. After my consultation session with them, I decided to opt for
                                        The
                                        Universal
                                        Writers. The service and time management are great here.</p>
                                </div>
                            </div>
                        </div>
                        <div class="swiper-slide">
                            <div class="testiMainBox">
                                <div class="testinameImage">
                                    <span class="nameIco">RG</span>
                                    <div class="nameStars">
                                        <span class="clientNameTesti">Ron Guzman</span>
                                        <div class="ratingStar">
                                            <i class="fa-solid fa-star"></i>
                                            <i class="fa-solid fa-star"></i>
                                            <i class="fa-solid fa-star"></i>
                                            <i class="fa-solid fa-star"></i>
                                            <i class="fa-solid fa-star"></i>
                                        </div>
                                    </div>
                                </div>
                                <div class="blogContent">
                                    <p>I wrote several rough drafts and sent the manuscript for multiple revisions.
                                        Still,
                                        PBP always
                                        helped me out with no complaints! Great work, guys!</p>
                                </div>
                            </div>
                        </div>
                        <div class="swiper-slide">
                            <div class="testiMainBox">
                                <div class="testinameImage">
                                    <span class="nameIco">CR</span>
                                    <div class="nameStars">
                                        <span class="clientNameTesti">Christina Rose</span>
                                        <div class="ratingStar">
                                            <i class="fa-solid fa-star"></i>
                                            <i class="fa-solid fa-star"></i>
                                            <i class="fa-solid fa-star"></i>
                                            <i class="fa-solid fa-star"></i>
                                            <i class="fa-solid fa-star"></i>
                                        </div>
                                    </div>
                                </div>
                                <div class="blogContent">
                                    <p>The Mystery is hard to write, even for authors who are not rookies. The Universal
                                        Writers helped
                                        me with all the nitty gritty details of fiction and created a piece of heart!
                                        This
                                        collaboration will
                                        always remain special to me!</p>
                                </div>
                            </div>
                        </div>
                        <div class="swiper-slide">
                            <div class="testiMainBox">
                                <div class="testinameImage">
                                    <span class="nameIco">LB</span>
                                    <div class="nameStars">
                                        <span class="clientNameTesti">Lily Anne Bowman</span>
                                        <div class="ratingStar">
                                            <i class="fa-solid fa-star"></i>
                                            <i class="fa-solid fa-star"></i>
                                            <i class="fa-solid fa-star"></i>
                                            <i class="fa-solid fa-star"></i>
                                            <i class="fa-solid fa-star"></i>
                                        </div>
                                    </div>
                                </div>
                                <div class="blogContent">
                                    <p>I wanted my fiction book to be filled with action; through Blue Pen Publishing
                                        and
                                        their action
                                        writing services, I was able to find a good mix of these two genres. Thanks to
                                        the
                                        team and the
                                        project manager for making this process smooth.</p>
                                </div>
                            </div>
                        </div>
                        <div class="swiper-slide">
                            <div class="testiMainBox">
                                <div class="testinameImage">
                                    <span class="nameIco">DR</span>
                                    <div class="nameStars">
                                        <span class="clientNameTesti">Dorothy K. Richard</span>
                                        <div class="ratingStar">
                                            <i class="fa-solid fa-star"></i>
                                            <i class="fa-solid fa-star"></i>
                                            <i class="fa-solid fa-star"></i>
                                            <i class="fa-solid fa-star"></i>
                                            <i class="fa-solid fa-star"></i>
                                        </div>
                                    </div>
                                </div>
                                <div class="blogContent">
                                    <p>Through the sci-fi cinema and movies of Christopher Nolan, I found myself deeply
                                        fascinated
                                        with the sci-fi genre and wanted to write something of my own. The ghostwriting
                                        services from
                                        PBPs made it so easy for me to write the first book that now I&#39;m planning to
                                        write a series of
                                        them!</p>
                                </div>
                            </div>
                        </div>
                        <div class="swiper-slide">
                            <div class="testiMainBox">
                                <div class="testinameImage">
                                    <span class="nameIco">DE</span>
                                    <div class="nameStars">
                                        <span class="clientNameTesti">Darek Elvis</span>
                                        <div class="ratingStar">
                                            <i class="fa-solid fa-star"></i>
                                            <i class="fa-solid fa-star"></i>
                                            <i class="fa-solid fa-star"></i>
                                            <i class="fa-solid fa-star"></i>
                                            <i class="fa-solid fa-star"></i>
                                        </div>
                                    </div>
                                </div>
                                <div class="blogContent">
                                    <p>Working with Blue Pen Publishing was a game changer for my business book. Their
                                        team of
                                        writers truly understood the messaging and tone I was going for, and their
                                        attention
                                        to detail was
                                        exceptional. The final product was exactly what I asked for, and I couldn&#39;t
                                        be
                                        happier with the
                                        end result.</p>
                                </div>
                            </div>
                        </div>
                        <div class="swiper-slide">
                            <div class="testiMainBox">
                                <div class="testinameImage">
                                    <span class="nameIco">JL</span>
                                    <div class="nameStars">
                                        <span class="clientNameTesti">Janet Laurel</span>
                                        <div class="ratingStar">
                                            <i class="fa-solid fa-star"></i>
                                            <i class="fa-solid fa-star"></i>
                                            <i class="fa-solid fa-star"></i>
                                            <i class="fa-solid fa-star"></i>
                                            <i class="fa-solid fa-star"></i>
                                        </div>
                                    </div>
                                </div>
                                <div class="blogContent">
                                    <p>I recently used Blue Pen Publishing for my romance novel, and I am extremely
                                        satisfied with
                                        the results. The team of writers was professional, responsive, and easy to work
                                        with
                                        throughout
                                        the entire process.</p>
                                </div>
                            </div>
                        </div>
                    </div>
                    <div class="swiper-pagination"></div>
                </div>
            </div>
        </div>
    </div>
</section>