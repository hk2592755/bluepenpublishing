<div class="bannerFormRightMain">
                    <div class="BannerformWrap">
                        <div class="bannerTitle">
                            <span>Free Expert Advice</span>
                        </div>
                        <div class="bannerFormWrap">
                            <div class="bannerWraptile">
                                <span class="sepTitle">Exclusive Discount</span>
                                <span class="offertitle">50% OFF On Our Services</span>
                                <div class="BannerFields">
                                    <form action="" method="post">
                                        <div class="formFields">
                                            <img src="assets/images/nameicon.svg" alt="Icon" />
                                            <input type="text" placeholder="Enter Your Name" name='Name' required />
                                        </div>
                                        <div class="formFields">
                                            <img src="assets/images/emailicon.svg" alt="Icon" />
                                            <input type="email" placeholder="Enter Your Email" name='Email' required />
                                        </div>
                                        <div class="formFields">
                                            <img src="assets/images/phoneicon.svg" alt="Icon" />
                                            <input type="text" placeholder="Your Phone Number" name='Number' required />
                                        </div>
                                        <div class="formFields FieldButton">
                                            <button type="submit" class="btnPrimary"><span>Submit <i class="fa-solid fa-arrow-right"></i></span>
                                            </button>
                                        </div>
                                        
                                    </form>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>