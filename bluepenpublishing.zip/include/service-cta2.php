<section class="sec9 philMain ProContent servingMainbox">
    <div class="container">
        <div class="row">
            <div class="col-md-6 ProContentLeft">
                <div class="abtLeft">
                    <h4>Spring Into Savings <br>
                        Get 20% Off Sitewide! </h4>
                    <p>
                        Dive into the world of affordable publishing deals, all book-inclusive services and launch
                        your
                        career as a pro author!
                    </p>
                    <div class="ctaWrap">
                        <div class="aboutCta">
                            <a href="javascript:;" class="btnPrimary openPopup">
                                <span>Request A Quote <i class="fa-solid fa-arrow-right"></i></span>
                            </a>
                        </div>
                    </div>
                </div>
            </div>
            <div class="col-md-6 proconImageLeft">
                <img src="assets/images/girlBgCircle.webp"
                    alt="Platform Images" />
            </div>
        </div>
    </div>
</section>