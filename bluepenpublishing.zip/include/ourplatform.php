 <section class="sec5 platforms">
    <div class="container">
        <div class="row">
            <div class="col-md-12 platformsTitle">
                <span class="smallHeading">Your book will be available</span>
                <span class="heading2 boldheading2">Our Publishing Platform</span>
            </div>
            <div class="col-md-12 logoWrapPlatforms">
                <div class="platformsInner proDesktop">
                    <img src="assets/images/logoMain.webp" alt="Platform Images"/>
                </div>
                <div class="platformsInner proMobile">
                    <img src="assets/images/logoMainMobile.webp" alt="Platform Images"/>
                </div>
            </div>
        </div>
    </div>
</section>